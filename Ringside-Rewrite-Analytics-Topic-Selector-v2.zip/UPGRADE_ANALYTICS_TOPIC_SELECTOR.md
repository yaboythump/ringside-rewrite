# Ringside Rewrite analytics topic selector upgrade

This upgrade keeps the existing one-button production path intact:

`RINGSIDE REWRITE scheduled production` → `new_episode` → `scripts/run_scheduled.py` → `scheduled_run()` → `create_episode()`

Only the topic decision underneath `generate_episode_plan()` changes.

## What changed

- Replaces the old random `idea_seeds.txt` choice with a ranked selector.
- Pulls recent YouTube upload stats through the existing YouTube credentials when available.
- Scores candidate topics using:
  - wrestler/star power,
  - storyline importance,
  - What-If curiosity,
  - performance of similar topics and formats on your own channel,
  - repeat/near-repeat blocking,
  - a small stable variety factor.
- Falls back safely if YouTube analytics are temporarily unavailable.
- Writes `output/topic-selection-latest.json` during a run so the selected topic can be audited.

## Files included

- `src/ringside/topic_selector.py`
- `src/ringside/studio.py`
- `tests/test_system.py`

No GitHub workflow file is changed by this package.
No channel config is changed by this package.
