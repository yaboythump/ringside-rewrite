from __future__ import annotations

import shutil
import subprocess
import tempfile
import unittest
from dataclasses import replace
from unittest.mock import patch
from pathlib import Path

from PIL import Image

from ringside.config import load_settings
from ringside.models import DialogueLine, EpisodePlan
from ringside.quality import evaluate_episode, evaluate_publish_assets
from ringside.render import _render_shot, probe_duration
from ringside.topic_selector import select_episode_topic
from ringside.youtube import _future_iso


ROOT = Path(__file__).resolve().parents[1]


class PilotTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.settings = load_settings(ROOT)
        cls.plan = EpisodePlan.load(ROOT / "content" / "pilot" / "episode.json")

    def test_pilot_passes_quality_gate(self) -> None:
        report = evaluate_episode(self.plan, self.settings.channel)
        self.assertTrue(report.passed, report.errors)
        self.assertGreaterEqual(self.plan.spoken_word_count, 1050)
        self.assertEqual(len(self.plan.shots), 24)
        self.assertTrue(self.plan.contains_synthetic_media)
        self.assertTrue(self.plan.original_fiction)
        self.assertTrue(self.plan.hypothetical_booking)
        self.assertGreaterEqual(len(self.plan.source_notes), 2)
        self.assertGreaterEqual(len(self.plan.factual_baseline), 3)
        self.assertIn("#RingsideRewrite", self.plan.hashtags)
        self.assertEqual(self.plan.slug, "sting-leads-the-invasion")

    def test_duplicate_visuals_fail(self) -> None:
        mutated = self.plan.model_copy(deep=True)
        mutated.shots[1].image_prompt = mutated.shots[0].image_prompt
        report = evaluate_episode(mutated, self.settings.channel)
        self.assertFalse(report.passed)
        self.assertTrue(any("exact duplicates" in error for error in report.errors))

    def test_missing_disclosure_fails(self) -> None:
        mutated = self.plan.model_copy(deep=True)
        mutated.contains_synthetic_media = False
        report = evaluate_episode(mutated, self.settings.channel)
        self.assertFalse(report.passed)
        self.assertTrue(any("disclosure" in error for error in report.errors))

    def test_direct_dialogue_fails(self) -> None:
        mutated = self.plan.model_copy(deep=True)
        mutated.shots[0].dialogue = [
            DialogueLine(speaker="Real Wrestler", text="This invented quote should fail.")
        ]
        report = evaluate_episode(mutated, self.settings.channel)
        self.assertFalse(report.passed)
        self.assertTrue(any("Direct dialogue" in error for error in report.errors))

    def test_subject_cooldown_fails(self) -> None:
        previous = self.plan.model_copy(deep=True)
        previous.slug = "prior-sting-episode"
        previous.episode_title = "Prior Sting Episode"
        report = evaluate_episode(self.plan, self.settings.channel, [previous])
        self.assertFalse(report.passed)
        self.assertTrue(any("cooldown" in error for error in report.errors))

    def test_scheduled_short_offset(self) -> None:
        self.assertEqual(
            _future_iso("2026-08-21T20:30:00Z", 2), "2026-08-23T20:30:00Z"
        )

    def test_cloud_oauth_values_load_from_environment(self) -> None:
        values = {
            "YOUTUBE_CLIENT_ID": "mobile-client-id",
            "YOUTUBE_CLIENT_SECRET_VALUE": "mobile-client-secret",
            "YOUTUBE_REFRESH_TOKEN": "mobile-refresh-token",
        }
        with patch.dict("os.environ", values, clear=False):
            settings = load_settings(ROOT)
        self.assertEqual(settings.youtube_client_id, values["YOUTUBE_CLIENT_ID"])
        self.assertEqual(
            settings.youtube_client_secret_value,
            values["YOUTUBE_CLIENT_SECRET_VALUE"],
        )
        self.assertEqual(
            settings.youtube_refresh_token, values["YOUTUBE_REFRESH_TOKEN"]
        )

    def test_research_config_loads(self) -> None:
        self.assertTrue(self.settings.research["research"]["web_search_enabled"])
        self.assertGreaterEqual(
            self.settings.research["research"]["minimum_sources"], 2
        )

    def test_visual_identity_schema_is_not_returned(self) -> None:
        schema = EpisodePlan.model_json_schema()
        self.assertNotIn("visual_identities", schema["properties"])

    def test_legacy_visual_identity_object_loads(self) -> None:
        payload = self.plan.model_dump()
        payload["visual_identities"] = {
            "Sasha Banks": "female presentation, Black woman, athletic build"
        }
        plan = EpisodePlan.model_validate(payload)
        self.assertEqual(plan.visual_identity_map, {})

    def test_duplicate_hashtags_are_cleaned_without_rejecting_plan(self) -> None:
        payload = self.plan.model_dump()
        payload["hashtags"] = ["#StoneCold", "WWE", "#WWE"]
        plan = EpisodePlan.model_validate(payload)
        self.assertEqual(
            plan.hashtags,
            ["#StoneCold", "#WWE", "#RingsideRewrite"],
        )

    def test_saved_publish_artifact_does_not_require_source_assets(self) -> None:
        with tempfile.TemporaryDirectory() as raw_dir:
            episode_dir = Path(raw_dir)
            (episode_dir / "shorts").mkdir()
            (episode_dir / "quality-assets.json").write_text(
                '{"passed": true, "errors": []}', encoding="utf-8"
            )
            (episode_dir / "final.mp4").write_bytes(b"v" * 100_000)
            (episode_dir / "thumbnail.png").write_bytes(b"i" * 10_000)
            (episode_dir / "captions.srt").write_text("captions", encoding="utf-8")
            for index in range(1, len(self.plan.shorts) + 1):
                (episode_dir / "shorts" / f"short-{index:02d}.mp4").write_bytes(
                    b"s" * 100_000
                )

            report = evaluate_publish_assets(self.plan, episode_dir)

        self.assertTrue(report.passed, report.errors)

    def test_saved_publish_artifact_requires_prior_quality_pass(self) -> None:
        with tempfile.TemporaryDirectory() as raw_dir:
            episode_dir = Path(raw_dir)
            (episode_dir / "shorts").mkdir()
            (episode_dir / "final.mp4").write_bytes(b"v" * 100_000)
            (episode_dir / "thumbnail.png").write_bytes(b"i" * 10_000)
            (episode_dir / "captions.srt").write_text("captions", encoding="utf-8")
            for index in range(1, len(self.plan.shorts) + 1):
                (episode_dir / "shorts" / f"short-{index:02d}.mp4").write_bytes(
                    b"s" * 100_000
                )

            report = evaluate_publish_assets(self.plan, episode_dir)

        self.assertFalse(report.passed)
        self.assertTrue(any("quality report" in error for error in report.errors))

    def test_topic_selector_respects_local_subject_cooldown(self) -> None:
        previous = self.plan.model_copy(deep=True)
        previous.slug = "prior-sting-episode"
        previous.episode_title = "Prior Sting Episode"
        choice = select_episode_topic(
            self.settings,
            recent_plans=[previous],
            analytics={"videos": []},
            save_report=False,
        )
        self.assertNotIn("Sting signed with WWE", choice.premise)

    def test_topic_selector_favors_performing_story_pattern(self) -> None:
        with tempfile.TemporaryDirectory() as raw_dir:
            settings = self._settings_with_seed_file(
                raw_dir,
                [
                    "What if The Shield never broke up in 2014?",
                    "What if Randy Savage returned to WWE for one final program in the early 2000s?",
                ],
                cooldown=0,
            )
            analytics = {
                "videos": [
                    {
                        "id": "hot",
                        "snippet": {
                            "title": "The Betrayal That Broke Wrestling #Shorts",
                            "description": (
                                "A huge faction betrayal, shocking breakup, and dramatic "
                                "turn at a major wrestling event."
                            ),
                            "tags": ["betrayal", "faction breakup", "major event"],
                            "publishedAt": "2026-08-29T12:00:00Z",
                        },
                        "statistics": {
                            "viewCount": "2500",
                            "likeCount": "180",
                            "commentCount": "30",
                        },
                    },
                    {
                        "id": "cold",
                        "snippet": {
                            "title": "A Quiet Legend Return",
                            "description": "A slower comeback story with a nostalgia hook.",
                            "tags": ["return", "legend"],
                            "publishedAt": "2026-08-28T12:00:00Z",
                        },
                        "statistics": {
                            "viewCount": "25",
                            "likeCount": "1",
                            "commentCount": "0",
                        },
                    },
                ]
            }
            choice = select_episode_topic(
                settings,
                analytics=analytics,
                now=self._fixed_now(),
                save_report=False,
            )
        self.assertEqual(choice.premise, "What if The Shield never broke up in 2014?")
        self.assertTrue(choice.analytics_used)

    def test_topic_selector_blocks_exact_used_seed_from_youtube_history(self) -> None:
        with tempfile.TemporaryDirectory() as raw_dir:
            settings = self._settings_with_seed_file(
                raw_dir,
                [
                    "What if Sasha Banks won the Women's Championship at WrestleMania 32?",
                    "What if The Rock joined the nWo in WWE in 2002?",
                ],
                cooldown=0,
            )
            analytics = {
                "videos": [
                    {
                        "id": "used",
                        "snippet": {
                            "title": "What If Sasha Banks Won WrestleMania 32?",
                            "description": (
                                "This upload was built from the exact premise: "
                                "What if Sasha Banks won the Women's Championship at "
                                "WrestleMania 32?"
                            ),
                            "tags": ["Sasha Banks", "WrestleMania"],
                            "publishedAt": "2026-08-25T12:00:00Z",
                        },
                        "statistics": {
                            "viewCount": "5000",
                            "likeCount": "300",
                            "commentCount": "40",
                        },
                    }
                ]
            }
            choice = select_episode_topic(
                settings,
                analytics=analytics,
                now=self._fixed_now(),
                save_report=False,
            )
        self.assertEqual(choice.premise, "What if The Rock joined the nWo in WWE in 2002?")

    def test_topic_selector_blocks_creative_title_for_same_story(self) -> None:
        with tempfile.TemporaryDirectory() as raw_dir:
            settings = self._settings_with_seed_file(
                raw_dir,
                [
                    "What if The Undertaker's WrestleMania streak never ended at WrestleMania 30?",
                    "What if The Rock joined the nWo in WWE in 2002?",
                ],
                cooldown=0,
            )
            analytics = {
                "videos": [
                    {
                        "id": "used-streak-story",
                        "snippet": {
                            "title": "The Night The Deadman's Streak Changed Forever",
                            "description": (
                                "Our Undertaker alternate-history episode asks what happens "
                                "when the legendary WrestleMania streak continues."
                            ),
                            "tags": ["Undertaker", "WrestleMania streak"],
                            "publishedAt": "2026-08-20T12:00:00Z",
                        },
                        "statistics": {"viewCount": "800", "likeCount": "40"},
                    }
                ]
            }
            choice = select_episode_topic(
                settings,
                analytics=analytics,
                now=self._fixed_now(),
                save_report=False,
            )
        self.assertEqual(choice.premise, "What if The Rock joined the nWo in WWE in 2002?")

    def test_topic_selector_writes_audit_report(self) -> None:
        with tempfile.TemporaryDirectory() as raw_dir:
            settings = self._settings_with_seed_file(
                raw_dir,
                ["What if The Rock joined the nWo in WWE in 2002?"],
                cooldown=0,
            )
            choice = select_episode_topic(
                settings,
                analytics={"videos": []},
                now=self._fixed_now(),
            )
            report_path = Path(raw_dir) / "output" / "topic-selection-latest.json"
            report = report_path.read_text(encoding="utf-8")
        self.assertIn(choice.premise, report)
        self.assertIn("analytics_driven_topic_selector_v2", report)

    def _settings_with_seed_file(
        self, raw_dir: str, seeds: list[str], cooldown: int
    ):
        root = Path(raw_dir)
        (root / "prompts").mkdir(parents=True)
        (root / "prompts" / "idea_seeds.txt").write_text(
            "\n".join(seeds) + "\n", encoding="utf-8"
        )
        channel = dict(self.settings.channel)
        channel["topic_selector"] = {"subject_cooldown_episodes": cooldown}
        return replace(self.settings, root=root, channel=channel)

    def _fixed_now(self):
        from datetime import datetime, timezone

        return datetime(2026, 8, 30, 12, 0, tzinfo=timezone.utc)


@unittest.skipUnless(shutil.which("ffmpeg") and shutil.which("ffprobe"), "FFmpeg unavailable")
class RenderSmokeTest(unittest.TestCase):
    def test_single_shot_render(self) -> None:
        with tempfile.TemporaryDirectory() as raw_dir:
            directory = Path(raw_dir)
            image = directory / "image.png"
            audio = directory / "audio.wav"
            video = directory / "shot.mp4"
            Image.new("RGB", (1536, 1024), (8, 18, 28)).save(image)
            subprocess.run(
                [
                    "ffmpeg",
                    "-y",
                    "-f",
                    "lavfi",
                    "-i",
                    "anullsrc=r=44100:cl=stereo",
                    "-t",
                    "1.0",
                    str(audio),
                ],
                check=True,
                capture_output=True,
            )
            _render_shot(image, audio, video, 1.0, "slow_push_in", 640, 360, 15)
            self.assertTrue(video.exists())
            self.assertGreater(video.stat().st_size, 1_000)
            self.assertGreater(probe_duration(video), 0.8)


if __name__ == "__main__":
    unittest.main()
